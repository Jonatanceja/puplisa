<?php

// @codeCoverageIgnoreStart
return [
    'emails/auth/login' => __DIR__ . '/templates/emails/auth/login.php',
    'emails/auth/password-reset' => __DIR__ . '/templates/emails/auth/password-reset.php'
];
// @codeCoverageIgnoreEnd
